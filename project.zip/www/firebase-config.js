// ============================================================
// Firebase Project Configuration
// ------------------------------------------------------------
// Go to https://console.firebase.google.com → your project →
// ⚙️ Project settings → scroll to "Your apps" → Web app →
// copy the firebaseConfig values shown there and paste below.
// ============================================================
export const firebaseConfig = {
  apiKey: "PASTE_YOUR_API_KEY_HERE",
  authDomain: "PASTE_YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "PASTE_YOUR_PROJECT_ID",
  storageBucket: "PASTE_YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "PASTE_YOUR_SENDER_ID",
  appId: "PASTE_YOUR_APP_ID"
};
