# Hill Top Tailor Shop — Android App (Bluetooth 80mm Printer)

Yeh folder ek Capacitor Android project ka scaffold hai. Isay asal Android app
mein badalne ke liye neeche diye steps follow karein. **Aapke apne Windows/Mac/Linux
computer par internet aur Android Studio chahiye hoga** — yahan sirf source files
tayyar ki gayi hain, compile aapko apne computer par karni hai.

## Kyun aise banaya gaya hai?

Sindhi/Urdu script wale bade bold numbers (jese aapki screenshot mein) cheap
Bluetooth thermal printers **text ke tor par print nahi kar sakte**. Is liye
receipt ko ek **image (tasveer)** ki tarah bana kar printer ko bheja jata hai —
isse har cheez bilkul waisi hi print hoti hai jaisi app mein dikh rahi hai.

## Zaroori Cheezein (ek dafa install karni hain)

1. **Node.js** — https://nodejs.org (LTS version)
2. **Android Studio** — https://developer.android.com/studio
   (isme Android SDK khud-ba-khud aa jata hai)
3. Ek Android phone/tablet jis par aapka **80mm Bluetooth thermal printer**
   pehle se pair (Bluetooth Settings se) ho chuka ho.

## Steps

### 1. Project banayein

Naya khali folder banayein (misal `TailorApp`) aur is `capacitor-app` folder ka
sara content us mein copy kar lein. Phir Command Prompt/Terminal us folder mein
kholein:

```
npm install
npx cap add android
```

Yeh command ek `android/` folder generate karegi (poora native Android project).

### 2. html2canvas library download karein

Yeh library receipt ko image mein badalne ke liye chahiye. Ismein internet chahiye:

- Yahan se download karein: https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js
- File ko `www/lib/html2canvas.min.js` mein save karein (`www/lib` folder pehle se
  is scaffold mein maujood hai, `www/index.html` bhi maujood hai).

### 3. Custom Bluetooth Printer Plugin daalein

`android-plugin-src/java/com/hilltoptailor/app/` mein do Java files hain:
- `BtPrinterPlugin.java`
- `MainActivity.java`

Inhein copy kar ke yahan paste karein (path `npx cap add android` ke baad banega):
```
android/app/src/main/java/com/hilltoptailor/app/
```
(Agar wahan pehle se `MainActivity.java` maujood ho, to hamari wali file se
replace kar dein — usmein plugin register karne wali line already shamil hai.)

### 4. AndroidManifest.xml update karein

`android-plugin-src/AndroidManifest-additions.xml` kholein — is file mein ab
do hisse hain, dono zaroori hain warna **Share Backup / Cloud Backup buttons
crash ho jayenge** ("Failed to find configured root..." error):

**a) `<uses-permission>` lines** — inhein copy kar ke apni
`android/app/src/main/AndroidManifest.xml` mein `<application>` tag se
thodi upar paste karein.

**b) `<provider>` block (FileProvider)** — `AndroidManifest-additions.xml`
mein iske upar likhe CASE A / CASE B instructions follow karein (pehle check
karein ke `<application>...</application>` ke andar pehle se koi
`FileProvider` `<provider>` maujood to nahi). Agar copy karte hain to
`android-plugin-src/res/xml/file_paths.xml` file ko bhi is jagah copy karein:
```
android/app/src/main/res/xml/file_paths.xml
```

### 5. Sync karein

```
npx cap sync android
```

### 6. Android Studio mein kholein aur build karein

```
npx cap open android
```

Android Studio khul jayegi. Upar menu se:
- Test/USB debug ke liye: apna phone USB se laga kar ▶ Run button dabayein
- Final APK banane ke liye: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
  APK `android/app/build/outputs/apk/debug/app-debug.apk` mein mil jayegi.
- Play Store ya doosre logon ko dene ke liye "Signed APK" banayein
  (Build → Generate Signed Bundle / APK) — Android Studio khud guide karta hai.

## App mein Printer Kaise Set Karein

1. Phone ki **Bluetooth Settings** se apna 80mm thermal printer pair karein
   (jese normal Bluetooth device pair hota hai).
2. App kholein → **Settings tab** → "🖨 Bluetooth 80mm Printer" card.
3. "🔄 Paired Printers Dekhein" dabayein — list mein apna printer dikhega.
4. Printer select kar ke "✅ Yeh Printer Select Karein" dabayein.
5. "🖨 Test Print" se check kar lein sab theek chal raha hai.
6. Ab jahan bhi app mein "80mm Slip" print karenge, seedha isi printer par jayega.

## Naye Features

- **Order Tracking search** — Order Tracking tab mein ab upar search bar hai,
  customer ka naam ya Serial Number type karte hi wo order turant filter ho
  kar dikh jata hai.
- **Cloud Backup / Share Backup** — Backup tab mein do naye button hain:
  "📤 Share Backup" (WhatsApp/Email/Drive kisi bhi app se bhejein) aur
  "☁️ Cloud Backup" (seedha Google Drive ki taraf le jata hai). Android par
  yeh backup file ko app ke Documents folder mein bhi reliably save karte hain.
- **Auto Backup** ab app background mein jaate hi bhi chal jata hai, sirf app
  band karte waqt nahi.
- **🔴 Real-Time Multi-Device Cloud Sync (naya, bada feature)** — neeche
  poora setup guide diya hai.

## 📱 App Ab Do Mode Mein Chalti Hai — Cloud Optional Hai

App khulte hi pehli baar ek **mode-selection screen** dikhati hai:

- **💻 Sirf Is Phone Par (Offline)** — koi login nahi, **internet ki bilkul
  zaroorat nahi**, kabhi bhi (pehli baar bhi) offline chalti hai. Data
  seedha isi phone ki IndexedDB mein save hota hai — bilkul waisi hi jaisi
  app pehle (Firebase se pehle) thi. Isay chunne wale users ke liye Firebase
  setup (neeche wale steps) ki koi zaroorat nahi.
- **☁️ Cloud Sync** — login mangegi, data Firebase mein save hoga aur sab
  logged-in phones par real-time sync hoga (neeche poora setup guide hai).

Jo mode ek baar select ho jaye wo us phone ke liye yaad rehta hai (dobara
nahi poochti). **Settings tab → "📱 App Mode"** se kabhi bhi mode badal
saktay hain. Ek mode ka data doosre mode mein khud-ba-khud nahi jata —
agar shift karna ho to **Backup tab se Export/Import** use karein.

**Cloud mode mein bhi** har entry apne aap isi phone ki local IndexedDB
mein bhi mirror ho jati hai — is liye internet chala jaye tab bhi aapka
data isi phone par mehfooz rehta hai (Firestore apna khud ka offline cache
bhi rakhta hai, is liye ek baar login karne ke baad thori der offline bhi
kaam chalta rehta hai).

## ☁️ Real-Time Cloud Sync Setup (3-10 Phones Ek Sath) — Sirf Cloud Mode Chunne Walon Ke Liye

**Agar aap "Sirf Is Phone Par (Offline)" mode chunte hain to neeche diye
saare steps skip kar sakte hain** — `firebase-config.js` ko haath lagane
ki bhi zaroorat nahi.

Cloud Sync mode mein ek phone par entry karein, baaki sab logged-in phones
par turant (real-time) dikh jayegi.

### Zaroori samajh lein

- Cloud Sync mode mein pehli baar login ke liye internet chahiye. Login
  hone ke baad thodi der offline bhi kaam kar sakti hai (data cache
  ho jata hai), lekin sync ke liye internet zaroori hai.
- **3 role hain:** Owner (sab kuch), Cutter (sirf cutting/orders/tracking),
  Tailor (sirf stitching/orders/tracking). Cutter aur Tailor **Cashbook,
  Payments, Worker salary, aur Settings nahi dekh/badal sakte** — yeh
  sirf Owner ke paas hai (dono UI mein chhupa hai aur server (Firestore)
  par bhi lock hai, is liye koi bhi tareeqe se bypass nahi ho sakta).

### Step 1: Firebase Project Banayein (Free)

1. https://console.firebase.google.com kholein, Google account se login karein.
2. **"Add project"** → koi bhi naam de dein (misal `hilltop-tailor`) → Continue
   → Google Analytics ka sawal aaye to "disable" kar dein → **Create project**.

### Step 2: Authentication On Karein

1. Left menu se **Build → Authentication** → **Get started**.
2. **Sign-in method** tab → **Email/Password** → enable karein → Save.

### Step 3: Firestore Database Banayein

1. Left menu se **Build → Firestore Database** → **Create database**.
2. **Production mode** select karein → apne qareeb wala region choose karein → Enable.

### Step 4: Security Rules Lagayein

1. Firestore Database → **Rules** tab.
2. Is folder mein `firestore.rules` file mein jo likha hai, wo sara copy kar ke
   yahan paste kar dein (jo pehle se likha hai usay replace kar dein).
3. **Publish** dabayein.

### Step 5: 3 Login Banayein (Owner, Cutter, Tailor)

1. **Authentication → Users tab → Add user**.
2. Har user ke liye ek **email** aur **password** dena hoga. Email format:
   ```
   username@hilltoptailor.local
   ```
   Misal: Owner ke liye `owner@hilltoptailor.local`, Cutter ke liye
   `cutter@hilltoptailor.local`, Tailor ke liye `tailor@hilltoptailor.local`.
   (App mein user sirf `owner`, `cutter`, `tailor` type karega — email khud
   ban jayega, aap ko yaad rakhne ki zarurat nahi.)
3. Password apni marzi ka rakh lein (kam az kam 6 characters).
4. Teeno users bana lein, aur har ek ka **User UID** copy kar lein (list mein
   naam ke saamne dikhta hai).

### Step 6: Har User Ka "Role" Set Karein

1. **Firestore Database → Data tab → Start collection**.
2. Collection ID: `users` → Next.
3. Document ID: **Owner ka jo UID copy kiya tha wo paste karein** (khud se mat likhein).
4. Fields add karein:
   - `role` (string) → `owner`
   - `username` (string) → `owner`
   - `displayName` (string) → `Owner` (ya jo naam chahen)
5. Save.
6. Yehi process Cutter ke liye dohrayein (Document ID = Cutter ka UID,
   `role` = `cutter`, `username` = `cutter`), aur Tailor ke liye bhi
   (`role` = `tailor`, `username` = `tailor`).

### Step 7: App Mein Config Dalein

1. Firebase console mein **⚙️ Project settings** (top-left gear icon) kholein.
2. Neeche scroll karein "Your apps" tak → **Web app (</> icon)** par click
   karein → app ka naam de kar register kar dein.
3. Jo `firebaseConfig = {...}` code dikhega, us ke andar ki saari values
   copy kar lein.
4. Is folder ki `www/firebase-config.js` file kholein aur `PASTE_YOUR_...`
   wali jagah apni asal values daal dein. Save kar dein.

### Login Kaise Karega Har Worker

App khulte hi login screen aayegi:
- **Owner:** username `owner`, jo password aapne diya tha
- **Cutter:** username `cutter`
- **Tailor:** username `tailor`

Jitne bhi phone is se login karenge (3, 5, 10 — koi limit nahi Firebase ke
free tier mein chhoti shop ke liye), sab par data real-time update hoga.

## Zaroori Baatein

- Yeh sirf **Android** ke liye hai (jaisa aapne bataya). iPhone alag setup mangta hai.
- **Offline mode** mein data sirf isi phone ki IndexedDB mein save hota hai —
  internet kabhi nahi chahiye. **Cloud Sync mode** mein data Firebase
  Firestore mein save hota hai, aur isi phone par bhi mirror hota hai taake
  internet chale jaye to kaam na ruke.
- Mode se pare, Backup (📄 Export / ☁️ Cloud Backup) ka istemal zaroor karte rahein.
- Har printer thora mukhtalif hota hai — agar print blurry ya adhoora aaye to
  `BtPrinterPlugin.java` mein `widthDots` value badal kar dekhein
  (80mm printers aam tor par 384 ya 576 dots width use karte hain — dono try karein).
- Yeh code ek starting point hai — real printer par test kar ke chhoti
  adjustments (margin, dot width) lag sakti hain.
