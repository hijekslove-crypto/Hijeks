package com.hilltoptailor.app;

import android.content.Intent;
import android.net.Uri;
import androidx.core.content.FileProvider;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/**
 * Shares the JSON backup file with an EXPLICIT "application/json" MIME type.
 *
 * Why this plugin exists: @capacitor/share's Share.share({ files: [...] })
 * lets Android's FileProvider guess the MIME type from the file extension.
 * On many devices/ROMs that lookup fails (older MimeTypeMap tables don't
 * know ".json"), Android falls back to a generic type, and receiving apps
 * like Google Drive's "Save to Drive" then save the file as .txt instead
 * of .json. Forcing the type here makes every target (WhatsApp, Google
 * Drive, Gmail, local "Files"/"My Files" storage app) save it with the
 * correct name and .json extension.
 */
@CapacitorPlugin(name = "BackupShare")
public class BackupSharePlugin extends Plugin {

    @PluginMethod
    public void shareJsonFile(PluginCall call) {
        String fileName = call.getString("fileName");
        String content = call.getString("content");
        String dialogTitle = call.getString("dialogTitle", "Backup kahan bhejni hai?");

        if (fileName == null || content == null) {
            call.reject("fileName aur content dono zaroori hain");
            return;
        }

        try {
            File dir = new File(getContext().getFilesDir(), "backups");
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, fileName);

            try (FileOutputStream fos = new FileOutputStream(file)) {
                fos.write(content.getBytes(StandardCharsets.UTF_8));
            }

            String authority = getContext().getPackageName() + ".fileprovider";
            Uri uri = FileProvider.getUriForFile(getContext(), authority, file);

            Intent sendIntent = new Intent(Intent.ACTION_SEND);
            sendIntent.setType("application/json");
            sendIntent.putExtra(Intent.EXTRA_STREAM, uri);
            sendIntent.putExtra(Intent.EXTRA_SUBJECT, fileName);
            sendIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

            Intent chooser = Intent.createChooser(sendIntent, dialogTitle);
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            // Grant read permission to every app that shows up in the chooser,
            // not just the first one — required on many OEM launchers/pickers.
            ArrayList<android.content.pm.ResolveInfo> resInfoList =
                new ArrayList<>(getContext().getPackageManager()
                    .queryIntentActivities(sendIntent, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY));
            for (android.content.pm.ResolveInfo resolveInfo : resInfoList) {
                String packageName = resolveInfo.activityInfo.packageName;
                getContext().grantUriPermission(packageName, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            }

            getContext().startActivity(chooser);

            JSObject result = new JSObject();
            result.put("uri", uri.toString());
            call.resolve(result);
        } catch (Exception e) {
            call.reject("Share fail hua: " + (e.getMessage() != null ? e.getMessage() : "Unknown error"));
        }
    }
}
