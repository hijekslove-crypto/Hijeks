package com.hilltoptailor.app;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;

/**
 * Bluetooth 80mm thermal printer plugin.
 *
 * Sends whatever image the web app hands it (a rendered PNG of the receipt)
 * to a paired Bluetooth printer as an ESC/POS raster bit image. Printing
 * as an image — instead of text — means Sindhi/Urdu labels and large bold
 * numbers print exactly as designed, since most cheap ESC/POS printers
 * cannot render that script as text.
 */
@CapacitorPlugin(
    name = "BtPrinter",
    permissions = {
        @Permission(strings = { Manifest.permission.BLUETOOTH_CONNECT }, alias = "bluetooth")
    }
)
public class BtPrinterPlugin extends Plugin {

    // Standard Serial Port Profile UUID used by virtually all cheap ESC/POS thermal printers
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @PluginMethod
    public void listPairedDevices(PluginCall call) {
        if (needsPermission()) {
            requestPermissionForAlias("bluetooth", call, "listPairedDevicesCallback");
            return;
        }
        doListPairedDevices(call);
    }

    @PermissionCallback
    private void listPairedDevicesCallback(PluginCall call) {
        if (needsPermission()) {
            call.reject("Bluetooth permission denied");
            return;
        }
        doListPairedDevices(call);
    }

    private void doListPairedDevices(PluginCall call) {
        try {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter == null) {
                call.reject("Is device par Bluetooth support nahi hai");
                return;
            }
            if (!adapter.isEnabled()) {
                call.reject("Bluetooth on karein aur dobara koshish karein");
                return;
            }
            Set<BluetoothDevice> bonded = adapter.getBondedDevices();
            JSArray devices = new JSArray();
            for (BluetoothDevice d : bonded) {
                JSObject o = new JSObject();
                o.put("name", d.getName());
                o.put("address", d.getAddress());
                devices.put(o);
            }
            JSObject result = new JSObject();
            result.put("devices", devices);
            call.resolve(result);
        } catch (SecurityException se) {
            call.reject("Bluetooth permission missing: " + se.getMessage());
        }
    }

    @PluginMethod
    public void printImage(PluginCall call) {
        if (needsPermission()) {
            requestPermissionForAlias("bluetooth", call, "printImageCallback");
            return;
        }
        doPrintImage(call);
    }

    @PermissionCallback
    private void printImageCallback(PluginCall call) {
        if (needsPermission()) {
            call.reject("Bluetooth permission denied");
            return;
        }
        doPrintImage(call);
    }

    private boolean needsPermission() {
        return getPermissionState("bluetooth") != com.getcapacitor.PermissionState.GRANTED
            && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S;
    }

    private void doPrintImage(final PluginCall call) {
        final String address = call.getString("address");
        final String base64 = call.getString("base64");
        final int widthDots = call.getInt("widthDots", 576); // 576 dots ≈ 80mm at 203dpi

        if (address == null || base64 == null) {
            call.reject("address aur base64 dono zaroori hain");
            return;
        }

        // Bluetooth I/O must not run on the main thread.
        new Thread(() -> {
            BluetoothSocket socket = null;
            try {
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter == null) throw new Exception("Bluetooth support nahi hai");
                BluetoothDevice device = adapter.getRemoteDevice(address);

                socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                adapter.cancelDiscovery();
                socket.connect();

                OutputStream out = socket.getOutputStream();

                byte[] imageBytes = Base64.decode(base64, Base64.DEFAULT);
                Bitmap original = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
                if (original == null) throw new Exception("Image decode nahi hui");

                Bitmap scaled = scaleToWidth(original, widthDots);
                byte[] escposCommands = bitmapToEscPosRaster(scaled, widthDots);

                out.write(new byte[]{0x1B, 0x40}); // ESC @  -> initialize printer
                out.write(escposCommands);
                out.write(new byte[]{0x0A, 0x0A, 0x0A, 0x0A}); // feed a few lines so the receipt clears the cutter
                out.flush();

                getActivity().runOnUiThread(() -> call.resolve());
            } catch (Exception e) {
                final String msg = e.getMessage() != null ? e.getMessage() : "Unknown print error";
                getActivity().runOnUiThread(() -> call.reject("Print fail hua: " + msg));
            } finally {
                if (socket != null) {
                    try { socket.close(); } catch (Exception ignored) {}
                }
            }
        }).start();
    }

    /** Resize the bitmap so its width matches the printer's dot width, keeping aspect ratio. */
    private Bitmap scaleToWidth(Bitmap src, int widthDots) {
        if (src.getWidth() == widthDots) return src;
        float ratio = (float) widthDots / (float) src.getWidth();
        int newHeight = Math.round(src.getHeight() * ratio);
        return Bitmap.createScaledBitmap(src, widthDots, newHeight, true);
    }

    /**
     * Converts a bitmap into ESC/POS "GS v 0" raster bit-image commands.
     * Each pixel is thresholded to black/white (1 bit per pixel, 8 pixels per byte),
     * which is the format virtually every cheap 80mm ESC/POS printer expects.
     */
    private byte[] bitmapToEscPosRaster(Bitmap bmp, int widthDots) throws Exception {
        int width = bmp.getWidth();
        int height = bmp.getHeight();
        int bytesPerRow = (int) Math.ceil(width / 8.0);

        ByteArrayOutputStream stream = new ByteArrayOutputStream();

        // Print in horizontal strips so we don't need one giant command for a tall receipt.
        int stripHeight = 256;
        for (int y0 = 0; y0 < height; y0 += stripHeight) {
            int h = Math.min(stripHeight, height - y0);

            stream.write(0x1D); stream.write('v'); stream.write('0'); stream.write(0x00); // GS v 0 m(=0 normal)
            stream.write(bytesPerRow & 0xFF);
            stream.write((bytesPerRow >> 8) & 0xFF);
            stream.write(h & 0xFF);
            stream.write((h >> 8) & 0xFF);

            for (int y = y0; y < y0 + h; y++) {
                byte[] rowBytes = new byte[bytesPerRow];
                for (int x = 0; x < width; x++) {
                    int pixel = bmp.getPixel(x, y);
                    int r = (pixel >> 16) & 0xFF;
                    int g = (pixel >> 8) & 0xFF;
                    int b = pixel & 0xFF;
                    int a = (pixel >> 24) & 0xFF;
                    int luminance = (r + g + b) / 3;
                    boolean isBlack = a > 30 && luminance < 180; // simple threshold
                    if (isBlack) {
                        rowBytes[x / 8] |= (byte) (0x80 >> (x % 8));
                    }
                }
                stream.write(rowBytes);
            }
        }
        return stream.toByteArray();
    }
}
